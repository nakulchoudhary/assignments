#include<bits/stdc++.h>
using namespace std;

class node{
public:
    int data;
    vector<node*> children;
};

void fx(node* rt){
    cout<<"Enter the node value: ";
        int temp;
        cin>>temp;
        rt->data = temp;
        int t2;
        cout<<"Enter the number of childern of node "<<temp<<" ";
        cin>>t2;
        for(int i = 0;i<t2;i++){
            cout<<"Enter the childe of node "<<temp<<" \n";
            node* rt2 = new node();
            fx(rt2);
            rt->children.push_back(rt2);
        }
}
void display(node* rt){
    queue<node*> q;
    q.push(rt);
    while(!q.empty()){
        int n = q.size();
        for(int i = 0;i<n;i++){
            node* t = q.front(); q.pop();
            for(auto x: t->children){
                q.push(x);
            }
            cout<<t->data<<" ";
        }
        cout<<"\n";
    }
}
void bfs(queue<node*> &q, bool &flag,int& to_search){
    if(q.empty() || flag)
        return;

    node* t = q.front();
    q.pop();
    cout<<t->data<<" ";
    if(t->data == to_search)
    {
        flag = true;
        cout<<" True";
        cout<<"\n\t Element Found!";
        return;
    }
    for(auto i:t->children)
        q.push(i);
    bfs(q,flag,to_search);
}
void dfs(node* rt,int& to_search,bool &flag){
    if(rt == NULL || flag) return ;
    cout<<rt->data<<" ";
    if(rt->data == to_search){
        flag = true;
        cout<<"\n Element Found!";
        return ;
    }
    for(auto x : rt->children){
        dfs(x,to_search,flag);
    }
}
int main(){
    node* rt = new node();
    fx(rt);
    display(rt);
    queue<node*> q;
    q.push(rt);
    bool f = false;
    int to_search;
    cout<<"Enter the search value ";
    cin>>to_search;
    bfs(q,f,to_search);
    cout<<"\n\n\n";
    f = false;
    dfs(rt,to_search,f);
    return 0;
}
