    import scala.collection.immutable._  
    object MainObject{  
        def main(args:Array[String]){  
            var vector1 = Vector(5,8,3,6,9,4) //Or  
            var vector2 = Vector(5,2,6,3)    
            println(vector1)  
            println(vector2)   
        }  
    }  
